import {
  MAT_BUTTON_CONFIG,
  MAT_FAB_DEFAULT_OPTIONS,
  MAT_FAB_DEFAULT_OPTIONS_FACTORY,
  MatAnchor,
  MatButton,
  MatButtonModule,
  MatFabAnchor,
  MatFabButton,
  MatIconAnchor,
  MatIconButton,
  MatMiniFabAnchor,
  MatMiniFabButton
} from "./chunk-SGTQQ7RN.js";
import "./chunk-G5LQ7BOM.js";
import "./chunk-Y23LKDWQ.js";
import "./chunk-3N4QCVNF.js";
import "./chunk-JRJSV4XM.js";
import "./chunk-ICVCCBBG.js";
import "./chunk-P3HFI4LE.js";
import "./chunk-OGRDD3DK.js";
import "./chunk-JIUJBXTE.js";
import "./chunk-T4ICZ2AZ.js";
import "./chunk-55RBBVZ3.js";
import "./chunk-UCLVMFV5.js";
export {
  MAT_BUTTON_CONFIG,
  MAT_FAB_DEFAULT_OPTIONS,
  MAT_FAB_DEFAULT_OPTIONS_FACTORY,
  MatAnchor,
  MatButton,
  MatButtonModule,
  MatFabAnchor,
  MatFabButton,
  MatIconAnchor,
  MatIconButton,
  MatMiniFabAnchor,
  MatMiniFabButton
};
//# sourceMappingURL=@angular_material_button.js.map
