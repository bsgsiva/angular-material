import {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatFormFieldModule,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError,
  matFormFieldAnimations
} from "./chunk-OLDCQXNB.js";
import "./chunk-LNTDLZYQ.js";
import "./chunk-FAJDLT27.js";
import "./chunk-G5LQ7BOM.js";
import "./chunk-Y23LKDWQ.js";
import "./chunk-3N4QCVNF.js";
import "./chunk-JRJSV4XM.js";
import "./chunk-ICVCCBBG.js";
import "./chunk-P3HFI4LE.js";
import "./chunk-OGRDD3DK.js";
import "./chunk-JIUJBXTE.js";
import "./chunk-T4ICZ2AZ.js";
import "./chunk-55RBBVZ3.js";
import "./chunk-UCLVMFV5.js";
export {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatFormFieldModule,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError,
  matFormFieldAnimations
};
//# sourceMappingURL=@angular_material_form-field.js.map
