import {
  ArrayDataSource,
  DataSource,
  SelectionModel,
  UniqueSelectionDispatcher,
  _DisposeViewRepeaterStrategy,
  _RecycleViewRepeaterStrategy,
  _VIEW_REPEATER_STRATEGY,
  _ViewRepeaterOperation,
  getMultipleValuesInSingleSelectionError,
  isDataSource
} from "./chunk-43F2C7Y4.js";
import "./chunk-JIUJBXTE.js";
import "./chunk-T4ICZ2AZ.js";
import "./chunk-55RBBVZ3.js";
import "./chunk-UCLVMFV5.js";
export {
  ArrayDataSource,
  DataSource,
  SelectionModel,
  UniqueSelectionDispatcher,
  _DisposeViewRepeaterStrategy,
  _RecycleViewRepeaterStrategy,
  _VIEW_REPEATER_STRATEGY,
  _ViewRepeaterOperation,
  getMultipleValuesInSingleSelectionError,
  isDataSource
};
//# sourceMappingURL=@angular_cdk_collections.js.map
