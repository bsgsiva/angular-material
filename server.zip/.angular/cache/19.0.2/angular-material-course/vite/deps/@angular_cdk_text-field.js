import {
  AutofillMonitor,
  CdkAutofill,
  CdkTextareaAutosize,
  TextFieldModule
} from "./chunk-C2X5YNBG.js";
import "./chunk-JRJSV4XM.js";
import "./chunk-P3HFI4LE.js";
import "./chunk-OGRDD3DK.js";
import "./chunk-JIUJBXTE.js";
import "./chunk-T4ICZ2AZ.js";
import "./chunk-55RBBVZ3.js";
import "./chunk-UCLVMFV5.js";
export {
  AutofillMonitor,
  CdkAutofill,
  CdkTextareaAutosize,
  TextFieldModule
};
//# sourceMappingURL=@angular_cdk_text-field.js.map
