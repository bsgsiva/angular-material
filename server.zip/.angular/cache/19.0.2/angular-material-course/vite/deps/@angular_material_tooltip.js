import {
  MAT_TOOLTIP_DEFAULT_OPTIONS,
  MAT_TOOLTIP_DEFAULT_OPTIONS_FACTORY,
  MAT_TOOLTIP_SCROLL_STRATEGY,
  MAT_TOOLTIP_SCROLL_STRATEGY_FACTORY,
  MAT_TOOLTIP_SCROLL_STRATEGY_FACTORY_PROVIDER,
  MatTooltip,
  MatTooltipModule,
  SCROLL_THROTTLE_MS,
  TOOLTIP_PANEL_CLASS,
  TooltipComponent,
  getMatTooltipInvalidPositionError,
  matTooltipAnimations
} from "./chunk-BPIBRXVB.js";
import "./chunk-HFRDBXKZ.js";
import "./chunk-BGKDUTL5.js";
import "./chunk-FAJDLT27.js";
import "./chunk-MU7RGPAJ.js";
import "./chunk-43F2C7Y4.js";
import "./chunk-G5LQ7BOM.js";
import "./chunk-Y23LKDWQ.js";
import "./chunk-3N4QCVNF.js";
import "./chunk-JRJSV4XM.js";
import "./chunk-ICVCCBBG.js";
import "./chunk-P3HFI4LE.js";
import "./chunk-OGRDD3DK.js";
import "./chunk-JIUJBXTE.js";
import "./chunk-T4ICZ2AZ.js";
import "./chunk-55RBBVZ3.js";
import "./chunk-UCLVMFV5.js";
export {
  MAT_TOOLTIP_DEFAULT_OPTIONS,
  MAT_TOOLTIP_DEFAULT_OPTIONS_FACTORY,
  MAT_TOOLTIP_SCROLL_STRATEGY,
  MAT_TOOLTIP_SCROLL_STRATEGY_FACTORY,
  MAT_TOOLTIP_SCROLL_STRATEGY_FACTORY_PROVIDER,
  MatTooltip,
  MatTooltipModule,
  SCROLL_THROTTLE_MS,
  TOOLTIP_PANEL_CLASS,
  TooltipComponent,
  getMatTooltipInvalidPositionError,
  matTooltipAnimations
};
//# sourceMappingURL=@angular_material_tooltip.js.map
